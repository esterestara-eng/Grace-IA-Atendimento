# GRACE — IA de Atendimento ao Cliente

Projeto escolar de Desenvolvimento de Sistemas.

## O que foi criado
- Interface de conversa com a Grace.
- Consulta de pedidos por número.
- Resposta de data, valor e status.
- Estrutura de cliente e pedido.
- Relacionamento CLIENTE (1) -> FAZ -> PEDIDO (N).
- Encaminhamento para atendente humano quando necessário.
- Arquivo SQL com o banco de dados do modelo do slide.

## Como executar

1. Instale o Node.js.
2. Abra o terminal dentro desta pasta.
3. Execute:
   node server.js
4. Abra no navegador:
   http://localhost:3000

Não é necessário instalar pacotes externos.

## Testes
Digite:
- Oi
- Qual o status do pedido 101?
- Qual o valor do pedido 102?
- Quero falar com um atendente.

## Observação
Esta versão é uma demonstração funcional da IA para o trabalho. Ela usa respostas programadas e dados de exemplo. Para uma IA generativa real, seria necessário conectar um serviço de modelo de linguagem por API.
