const form = document.getElementById("chatForm");
const input = document.getElementById("message");
const messages = document.getElementById("messages");

function addMessage(text, type) {
  const div = document.createElement("div");
  div.className = `msg ${type}`;
  div.innerHTML = `<strong>${type === "user" ? "Você" : "Grace"}</strong><p></p>`;
  div.querySelector("p").textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

async function sendMessage(text) {
  addMessage(text, "user");
  input.value = "";

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text })
    });
    const data = await response.json();
    addMessage(data.assistant || data.error || "Não consegui responder.", "grace");
  } catch {
    addMessage("Não consegui conectar ao servidor. Verifique se o Grace está rodando.", "grace");
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  if (input.value.trim()) sendMessage(input.value.trim());
});

document.querySelectorAll(".quick").forEach(btn => {
  btn.addEventListener("click", () => sendMessage(btn.dataset.msg));
});
