CREATE DATABASE grace_atendimento;
USE grace_atendimento;

CREATE TABLE cliente (
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150),
    telefone VARCHAR(20)
);

CREATE TABLE pedido (
    id_pedido INT PRIMARY KEY AUTO_INCREMENT,
    id_cliente INT NOT NULL,
    data DATE NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    status VARCHAR(50) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
);

INSERT INTO cliente (nome, email, telefone) VALUES
('Maria', 'maria@email.com', '(11) 99999-1111'),
('João', 'joao@email.com', '(11) 98888-2222');

INSERT INTO pedido (id_cliente, data, valor, status) VALUES
(1, '2026-09-28', 149.90, 'Em preparação'),
(1, '2026-09-25', 89.90, 'Enviado'),
(2, '2026-09-27', 219.90, 'Entregue');
