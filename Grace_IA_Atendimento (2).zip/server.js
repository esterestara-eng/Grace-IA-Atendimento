const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const PORT = 3000;

const clientes = [
  { id_cliente: 1, nome: "Maria", email: "maria@email.com", telefone: "(11) 99999-1111" },
  { id_cliente: 2, nome: "João", email: "joao@email.com", telefone: "(11) 98888-2222" }
];

const pedidos = [
  { id_pedido: 101, id_cliente: 1, data: "2026-09-28", valor: 149.90, status: "Em preparação" },
  { id_pedido: 102, id_cliente: 1, data: "2026-09-25", valor: 89.90, status: "Enviado" },
  { id_pedido: 103, id_cliente: 2, data: "2026-09-27", valor: 219.90, status: "Entregue" }
];

function send(res, status, data, type = "application/json") {
  res.writeHead(status, {
    "Content-Type": `${type}; charset=utf-8`,
    "Access-Control-Allow-Origin": "*"
  });
  res.end(type === "application/json" ? JSON.stringify(data) : data);
}

function grace(message) {
  const text = message.toLowerCase().trim();

  if (/^(oi|olá|ola|bom dia|boa tarde|boa noite)\b/.test(text)) {
    return "Olá! Eu sou a Grace 😊 Como posso ajudar você? Posso consultar pedidos, valores, datas e status.";
  }

  const match = text.match(/(?:pedido|n[º°]?)\s*#?\s*(\d+)/i);
  if (match) {
    const id = Number(match[1]);
    const pedido = pedidos.find(p => p.id_pedido === id);

    if (!pedido) {
      return `Não encontrei o pedido ${id}. Confira o número e tente novamente.`;
    }

    const cliente = clientes.find(c => c.id_cliente === pedido.id_cliente);
    return `Encontrei o pedido ${pedido.id_pedido} de ${cliente?.nome || "cliente"}.\nData: ${pedido.data}\nValor: R$ ${pedido.valor.toFixed(2).replace(".", ",")}\nStatus: ${pedido.status}.`;
  }

  if (text.includes("status") || text.includes("pedido")) {
    return "Claro! Me informe o número do pedido, por exemplo: “Qual o status do pedido 101?”";
  }

  if (text.includes("valor") || text.includes("preço") || text.includes("preco")) {
    return "Posso consultar o valor de um pedido. Me informe o número do pedido.";
  }

  if (text.includes("cliente") || text.includes("cadastro")) {
    return "Posso trabalhar com nome, e-mail e telefone do cliente. Para uma alteração de cadastro, posso encaminhar você para um atendente humano.";
  }

  if (text.includes("humano") || text.includes("atendente") || text.includes("falar com alguém")) {
    return "Claro. Esse atendimento será encaminhado para um atendente humano.";
  }

  return "Ainda não entendi essa solicitação. Posso ajudar com clientes e pedidos, incluindo data, valor e status. Se precisar de algo mais complexo, posso encaminhar para um atendente humano.";
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === "GET" && url.pathname === "/api/clientes") {
    return send(res, 200, clientes);
  }

  if (req.method === "GET" && url.pathname === "/api/pedidos") {
    return send(res, 200, pedidos);
  }

  if (req.method === "POST" && url.pathname === "/api/chat") {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", () => {
      try {
        const data = JSON.parse(body || "{}");
        if (!data.message) return send(res, 400, { error: "Mensagem não informada." });
        send(res, 200, { assistant: grace(data.message) });
      } catch {
        send(res, 400, { error: "JSON inválido." });
      }
    });
    return;
  }

  // Arquivos da interface
  let filePath = url.pathname === "/" ? path.join(__dirname, "index.html")
                                      : path.join(__dirname, url.pathname);

  if (!filePath.startsWith(__dirname)) return send(res, 403, "Acesso negado.", "text/plain");

  fs.readFile(filePath, (err, data) => {
    if (err) return send(res, 404, "Arquivo não encontrado.", "text/plain");
    const ext = path.extname(filePath);
    const types = { ".html": "text/html", ".css": "text/css", ".js": "text/javascript" };
    send(res, 200, data, types[ext] || "text/plain");
  });
});

server.listen(PORT, () => {
  console.log(`Grace funcionando em http://localhost:${PORT}`);
});
